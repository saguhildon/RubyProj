class CreateRooms < ActiveRecord::Migration[6.0]
  def self.up
    create_table :rooms do |t|
       
         t.column :buildingname, :string        
         t.column :floor, :string
         t.column :roomname, :string
         t.column :intime, :timestamp
         t.column :outtime, :timestamp
         t.column :created_at, :timestamp
    end
    Room.create(:buildingname => "TechPoint", :floor => "L1", :roomname => "TECH-01", :intime => '2020-06-07 23:00:07', :outtime => '2020-06-07 23:50:07')
    Room.create(:buildingname => "TechPoint", :floor => "L1", :roomname => "TECH-02")
    Room.create(:buildingname => "TechPoint", :floor => "L1", :roomname => "TECH-03")
    Room.create(:buildingname => "TechPoint", :floor => "L1", :roomname => "TECH-04")
    Room.create(:buildingname => "TechPoint", :floor => "L1", :roomname => "TECH-05")
    Room.create(:buildingname => "TechPoint", :floor => "L1", :roomname => "TECH-06")
    Room.create(:buildingname => "TechPoint", :floor => "L1", :roomname => "TECH-07")
  end


  def self.down
    drop_table :rooms
  end
end
