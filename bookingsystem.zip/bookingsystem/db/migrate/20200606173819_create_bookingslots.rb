class CreateBookingslots < ActiveRecord::Migration[6.0]
  def self.up
    create_table :bookingslots do |t|
      
      t.column :buildingname, :string        
      t.column :floor, :string
      t.column :roomname, :string
      t.column :intime, :timestamp
      t.column :outtime, :timestamp
      t.column :created_at, :timestamp
    end
  end
  def self.down
    drop_table :bookingslots
  end
end
