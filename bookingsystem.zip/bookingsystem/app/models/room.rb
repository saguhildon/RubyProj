class Room < ApplicationRecord
has_many :bookingslots
end
