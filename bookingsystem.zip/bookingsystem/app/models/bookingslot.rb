class Bookingslot < ApplicationRecord
    belongs_to :room
end
