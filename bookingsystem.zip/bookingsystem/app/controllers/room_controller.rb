class RoomController < ApplicationController
    layout 'standard'
    def list
        @rooms = Room.all
    end
    
    def show
        @room = Room.find(params[:id])
    end
    
    def new
    end
    
    def create
    end

    def room_param
        params.require(:rooms).permit(:buildingname, :floor, :roomname, :intime, :outtime, "y")
     end

    def edit
        @room = Room.find(params[:id])
    end
    
    def update
        @room = Room.find(params[:id])
	
   if @room.update_attributes(room_param)
      redirect_to :action => 'list'
   else
      @room = Room.all
      render :action => 'list'
    end
end
    def delete
    end

    def row_classname(type)
        if type != ''
            classname='red'
        else 
            classname = 'green'
        end
       
      
         "class=\"#{classname}\"" unless classname.nil?
      
      end
end
