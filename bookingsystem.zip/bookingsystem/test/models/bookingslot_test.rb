require 'test_helper'

class BookingslotTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
